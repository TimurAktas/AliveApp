<template>
    <Page>
        <ActionBar title="Welcome to NativeScript-Vue!" android:flat="true"/>
        <TabView android:tabBackgroundColor="#53ba82"
                 android:tabTextColor="#c4ffdf"
                 android:selectedTabTextColor="#ffffff"
                 androidSelectedTabHighlightColor="#ffffff">
            <TabViewItem title="Dashboarddddd">
                <GridLayout columns="*" rows="*">
                    <Label class="message" :text="msg" col="0" row="0"/>
                </GridLayout>
            </TabViewItem>
            <TabViewItem title="Maapp">
                 <test />
            </TabViewItem>
            <TabViewItem title="ProfilTaasdasdadsimur">
                   <Karte />
            </TabViewItem>
        </TabView>
    </Page>
</template>

<script >
import test from './test'
import Karte from './Karte'
  export default {
    components: {
        test,
        Karte,
    },
    data() {
      return {
        msg: 'TestS'
      }
    }
  }
</script>

<style >
    ActionBar {
        background-color: green;
        color: #ffffff;
    }

    .message {
        vertical-align: center;
        text-align: center;
        font-size: 20;
        color: #333333;
    }
</style>
