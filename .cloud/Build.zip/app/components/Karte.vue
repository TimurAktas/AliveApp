<template>
<GridLayout columns="*" rows="*">
    <Label class="message" :text="datenName" col="0" row="0"/>
</GridLayout>    
</template>

<script>
export default {
    data(){
        return{
            datenName: 'Dadasdasd'
        }
    }
}
</script>

<style>

</style>