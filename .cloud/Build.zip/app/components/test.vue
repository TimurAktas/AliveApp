<template>
<GridLayout columns="*" rows="*">
    <Label class="message" text="Tab2322 Content" col="0" row="0"/>


</GridLayout>    
</template>

<script>
export default {
    
}
</script>

<style >

</style>